# ruchithagowda10.test_collection

This collection contains a role to install and start Nginx on Ubuntu.
