# nginx_install

Role to install and start Nginx web server.
